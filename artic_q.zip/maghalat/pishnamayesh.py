#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pishnamayesh.py — پیش‌نمایش آفلاین قالب برای هر مقالهٔ تبدیل‌شده.
CSS/JS را مستقیم از qpedia-tpl.php.txt می‌خواند تا پیش‌نمایش و سایت یکی بمانند.
    python3 pishnamayesh.py                → همهٔ مقالات html/
    python3 pishnamayesh.py نام-فایل       → فقط یکی
"""
import re, os, sys, json, html

TPL  = '/home/user/qpedia-audit/qpedia-tpl.php.txt'
HTML = '/home/user/maghalat/html'
OUT  = '/home/user/maghalat/preview'
META = '/home/user/maghalat/meta.json'
os.makedirs(OUT, exist_ok=True)

src = open(TPL, encoding='utf-8').read()
CSS = re.search(r'<style id="qpt-css">(.*?)</style>', src, re.S).group(1)
JS  = re.search(r'<script id="qpt-js">(.*?)</script>', src, re.S).group(1)

meta = json.load(open(META, encoding='utf-8')) if os.path.exists(META) else {}
fa = lambda n: str(n).translate(str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹'))


def build(stem):
    body = open(f'{HTML}/{stem}.html', encoding='utf-8').read()
    m = meta.get(stem, {})

    items, seen = [], {}

    def anchor(t):
        x = re.sub(r'<[^>]+>', '', t)
        x = re.sub(r'[^\w\s-]', '', x, flags=re.U).strip()
        x = re.sub(r'\s+', '-', x) or 'bakhsh'
        s = 'q-' + x
        if s in seen:
            seen[s] += 1; s = f'{s}-{seen[s]}'
        else:
            seen[s] = 1
        return s

    state = {'faq': False}

    def rep(mo):
        lvl, txt = int(mo.group(1)), mo.group(3)
        i = anchor(txt)
        plain = re.sub('<[^>]+>', '', txt)
        if lvl == 2:
            state['faq'] = any(k in plain for k in ('پرسش', 'سوال', 'سؤال'))
        warm = ' is-faq' if state['faq'] else ''
        rec = {'id': i, 'text': plain}
        if lvl == 2:
            items.append(dict(rec, sub=[]))
        elif items:
            items[-1]['sub'].append(rec)
        return (f'<h{lvl} id="{i}" class="qpt-h{warm}">{txt}'
                f'<a class="qpt-anchor" href="#{i}">#</a></h{lvl}>')

    body = re.sub(r'<h([23])(\s[^>]*)?>(.*?)</h\1>', rep, body, flags=re.S | re.I)

    toc = ''
    if len(items) >= 3:
        toc = ('<nav class="qpt-toc"><div class="qpt-toc__grid"></div>'
               '<button class="qpt-toc__tog" aria-expanded="true">'
               '<span class="qpt-toc__ttl">فهرست مطالب</span>'
               '<span class="qpt-toc__ar"></span></button><ol class="qpt-toc__list">')
        for n, it in enumerate(items, 1):
            toc += (f'<li><a href="#{it["id"]}"><span class="qpt-toc__n">{fa(n)}</span>'
                    f'{html.escape(it["text"])}</a>')
            if it['sub']:
                toc += '<ul>' + ''.join(
                    f'<li><a href="#{s["id"]}">{html.escape(s["text"])}</a></li>'
                    for s in it['sub']) + '</ul>'
            toc += '</li>'
        toc += '</ol></nav>'

    words = len(re.findall(r'\S+', re.sub('<[^>]+>', ' ', body)))
    mins = max(1, round(words / 200))
    title = m.get('title', stem)
    en = m.get('en', '')
    lead = m.get('lead') or re.sub('<[^>]+>', '', body).strip()[:190] + '…'

    chips = ''.join(f'<a class="qpt-chip" href="#">{html.escape(c)}</a>'
                    for c in m.get('chips', []))
    card = (f'<div class="qpt-card"><div class="qpt-card__grid"></div>'
            f'<div class="qpt-card__body"><div class="qpt-card__head">'
            f'<h2 class="qpt-card__title">{html.escape(title)}</h2>'
            + (f'<div class="qpt-card__en" dir="ltr">{html.escape(en)}</div>' if en else '')
            + f'</div><p class="qpt-card__lead">{html.escape(lead)}</p>'
              f'<div class="qpt-card__meta">'
              f'<span class="qpt-meta"><span class="qpt-dot"></span>{fa(mins)} دقیقه مطالعه</span>'
              f'<span class="qpt-meta"><span class="qpt-dot"></span>بروزرسانی ۳۱ مرداد ۱۴۰۵</span>'
              f'</div>'
            + (f'<div class="qpt-chips">{chips}</div>' if chips else '')
            + '</div></div>')

    key = ''
    if m.get('nokat'):
        key = ('<aside class="qpt-key"><div class="qpt-key__grid"></div>'
               '<h2 class="qpt-key__ttl">نکات کلیدی</h2><ul>'
               + ''.join(f'<li>{html.escape(x)}</li>' for x in m['nokat'])
               + '</ul></aside>')

    def grp(lbl, chips_, cls):
        if not chips_:
            return ''
        return (f'<div class="qpt-rel__group"><h3 class="qpt-rel__lbl">{lbl}</h3>'
                '<div class="qpt-rel__row">'
                + ''.join(f'<a class="qpt-rel__chip {cls}" href="#">{html.escape(c)}</a>'
                          for c in chips_) + '</div></div>')

    relbody = (grp('اصطلاحات مرتبط', m.get('terms', []), 'is-term')
               + grp('دانشمندان مرتبط', m.get('scientists', []), 'is-sci')
               + grp('مقالات مرتبط', m.get('articles', []), 'is-art'))
    rel = ('<section class="qpt-rel"><div class="qpt-rel__grid"></div>'
           '<h2 class="qpt-rel__ttl">در همین زمینه</h2>' + relbody + '</section>') if relbody else ''

    pn = ('<nav class="qpt-pn">'
          '<a class="qpt-pn__a is-prev" href="#"><span class="qpt-pn__k">مقالهٔ قبلی</span>'
          '<span class="qpt-pn__t">' + html.escape(m.get('prev', 'مقالهٔ پیشین')) + '</span></a>'
          '<a class="qpt-pn__a is-next" href="#"><span class="qpt-pn__k">مقالهٔ بعدی</span>'
          '<span class="qpt-pn__t">' + html.escape(m.get('next', 'مقالهٔ بعدی')) + '</span></a></nav>')

    page = f'''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)} — پیش‌نمایش</title><style>
body{{margin:0;background:#f4f7fc;color:#1a202c;
 font-family:'Vazirmatn',Tahoma,system-ui,sans-serif;line-height:1.7}}
.wrap{{max-width:820px;margin:0 auto;padding:30px 20px 70px}}
.note{{margin:0 0 24px;padding:11px 16px;border-radius:10px;font-size:.84rem;
 border:1px dashed #15734a;color:#15734a;background:#eef7f2}}
h1.pg{{font-size:1.8rem;color:#0b1a3a;margin:0 0 8px;line-height:1.5}}
{CSS}
</style></head><body><div class="wrap">
<p class="note">پیش‌نمایش آفلاین — همین ساختار روی هر مقاله در سایت خودکار اعمال می‌شود.</p>
<h1 class="pg">{html.escape(title)}</h1>
<div class="qpt">{card}{toc}<div class="qpt-body">{body}</div>{key}{rel}{pn}</div>
</div><script>{JS}</script></body></html>'''

    dst = f'{OUT}/{stem}.html'
    open(dst, 'w', encoding='utf-8').write(page)
    return dst, words, len(items)


if __name__ == '__main__':
    names = ([sys.argv[1].removesuffix('.html')] if len(sys.argv) > 1
             else [f[:-5] for f in sorted(os.listdir(HTML)) if f.endswith('.html')])
    for nm in names:
        p, w, h = build(nm)
        print(f'{p}  |  {w} کلمه  |  {h} تیتر H2')
