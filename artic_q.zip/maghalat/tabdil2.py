#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tabdil.py — تبدیل فایل‌های ورد / متنی به HTML تمیز برای Qpedia
--------------------------------------------------------------
ورودی : هر فایل .docx یا .txt یا .md داخل  /home/user/maghalat/khaam/
خروجی : یک فایل .html تمیز به ازای هر ورودی داخل /home/user/maghalat/html/
         + گزارش  /home/user/maghalat/gozaresh2.md

اصول خروجی:
  • هیچ style/class اضافه‌ای تولید نمی‌شود (قالب در زمان نمایش اعمال می‌شود)
  • فقط: h2 h3 h4 p ul ol li strong em blockquote table a
  • h1 حذف می‌شود و به‌عنوان «عنوان پست» جدا برداشته می‌شود
  • فاصله‌های مجازی و نیم‌فاصله اصلاح می‌شود
  • ی/ک عربی به فارسی تبدیل می‌شود
"""

import os, re, sys, json, html, unicodedata

KHAAM = "/home/user/maghalat/khaam2"
OUT   = "/home/user/maghalat/html2"
os.makedirs(OUT, exist_ok=True)

ALLOWED = {"h2","h3","h4","p","ul","ol","li","strong","em","b","i",
           "blockquote","table","thead","tbody","tr","td","th","a","br","sup","sub","code","pre"}

# ---------- پاک‌سازی متن فارسی ----------
FIX = {
    "\u064a": "\u06cc",   # ي عربی -> ی
    "\u0643": "\u06a9",   # ك عربی -> ک
    "\u06c0": "\u0647\u200c\u06cc",
    "\u0640": "",         # کشیده
    "\u200f": "", "\u200e": "",
    "\u00a0": " ",
}
ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "۰۱۲۳۴۵۶۷۸۹")

def clean_text(t):
    for a, b in FIX.items():
        t = t.replace(a, b)
    t = t.translate(ARABIC_DIGITS)
    t = re.sub(r"[ \t]{2,}", " ", t)
    t = re.sub(r" ([،؛:.؟!»])", r"\1", t)
    t = re.sub(r"([«]) ", r"\1", t)
    return t.strip()


# ---------- خواندن docx ----------
def read_docx(path):
    import mammoth
    style_map = """
    p[style-name='Title']     => h1:fresh
    p[style-name='عنوان']     => h1:fresh
    p[style-name='Subtitle']  => p:fresh
    p[style-name='Heading 1'] => h2:fresh
    p[style-name='Heading 2'] => h3:fresh
    p[style-name='Heading 3'] => h4:fresh
    p[style-name='Heading 4'] => h4:fresh
    p[style-name='عنوان 1']   => h2:fresh
    p[style-name='عنوان 2']   => h3:fresh
    p[style-name='عنوان 3']   => h4:fresh
    p[style-name='Quote']         => blockquote:fresh
    p[style-name='Intense Quote'] => blockquote:fresh
    """
    with open(path, "rb") as f:
        res = mammoth.convert_to_html(f, style_map=style_map)
    return res.value, [m.message for m in res.messages]


# ---------- خواندن txt / md ----------
def read_plain(path):
    raw = open(path, encoding="utf-8", errors="replace").read()
    out, msgs = [], []
    for block in re.split(r"\n\s*\n", raw):
        b = block.strip()
        if not b:
            continue
        m = re.match(r"^(#{1,4})\s+(.*)$", b)
        if m:
            lvl = min(max(len(m.group(1)), 2), 4)
            out.append(f"<h{lvl}>{html.escape(m.group(2).strip())}</h{lvl}>")
            continue
        lines = [l.strip() for l in b.split("\n") if l.strip()]
        if all(re.match(r"^[-*•]\s+", l) for l in lines):
            items = "".join(f"<li>{html.escape(re.sub(r'^[-*•]\s+','',l))}</li>" for l in lines)
            out.append(f"<ul>{items}</ul>"); continue
        if all(re.match(r"^\d+[.)]\s+", l) for l in lines):
            items = "".join(f"<li>{html.escape(re.sub(r'^\d+[.)]\s+','',l))}</li>" for l in lines)
            out.append(f"<ol>{items}</ol>"); continue
        # خط کوتاه و بدون نقطه‌ی پایانی = احتمالاً تیتر
        if len(lines) == 1 and len(lines[0]) < 60 and not re.search(r"[.،؛:]$", lines[0]):
            out.append(f"<h2>{html.escape(lines[0])}</h2>"); continue
        out.append("<p>" + html.escape(" ".join(lines)) + "</p>")
    return "\n".join(out), msgs


# ---------- تمیزکاری HTML ----------
def sanitize(raw_html):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(raw_html, "html.parser")

    # h1 -> عنوان پست
    title = None
    h1 = soup.find("h1")
    if h1:
        title = clean_text(h1.get_text(" ", strip=True))
        h1.decompose()

    for tag in soup.find_all(True):
        name = tag.name.lower()
        if name == "img":
            tag.decompose(); continue
        if name not in ALLOWED:
            tag.unwrap(); continue
        attrs = {}
        if name == "a" and tag.get("href"):
            attrs["href"] = tag["href"]
            if tag["href"].startswith("http") and "qpedia.ir" not in tag["href"]:
                attrs["rel"] = "noopener nofollow"
                attrs["target"] = "_blank"
        tag.attrs = attrs

    # اگر h1 نبود، اولین h2 را عنوان بگیر
    if not title:
        h2 = soup.find("h2")
        if h2:
            title = clean_text(h2.get_text(" ", strip=True))
            h2.decompose()

    for node in soup.find_all(string=True):
        if node.parent.name not in ("code", "pre"):
            node.replace_with(clean_text(str(node)))

    # **پررنگ** و *مورب* به سبک مارک‌داون → تگ واقعی
    out_html = str(soup)
    out_html = re.sub(r"\*\*(?!\s)(.+?)(?<!\s)\*\*", r"<strong>\1</strong>", out_html, flags=re.S)
    out_html = re.sub(r"(?<![\w*])\*(?!\s)([^*\n]+?)(?<!\s)\*(?![\w*])", r"<em>\1</em>", out_html)
    soup = BeautifulSoup(out_html, "html.parser")

    for p in soup.find_all(["p", "li"]):
        if not p.get_text(strip=True) and not p.find(["br", "a"]):
            p.decompose()

    out = str(soup)
    out = re.sub(r"\n{3,}", "\n\n", out)
    out = re.sub(r">\s+<", ">\n<", out)
    return title, out.strip()


def slugify_hint(title):
    """فقط یک پیشنهاد؛ اسلاگ نهایی را دستی تأیید می‌کنیم."""
    t = re.sub(r"[^\w\s-]", "", title or "", flags=re.U).strip().lower()
    return re.sub(r"[\s_]+", "-", t)[:60]


def main():
    files = sorted(
        f for f in os.listdir(KHAAM)
        if f.lower().endswith((".docx", ".txt", ".md"))
        and not f.startswith("~$") and not f.startswith("_")
    )
    if not files:
        print(f"هیچ فایلی در {KHAAM} پیدا نشد.")
        print("فایل‌های .docx یا .txt را آنجا آپلود کنید و دوباره اجرا کنید.")
        return

    rows, manifest = [], []
    for fn in files:
        src = os.path.join(KHAAM, fn)
        try:
            if fn.lower().endswith(".docx"):
                raw, msgs = read_docx(src)
            else:
                raw, msgs = read_plain(src)
            title, body = sanitize(raw)
        except Exception as e:
            rows.append((fn, "—", 0, 0, 0, f"خطا: {e}"))
            continue

        base = os.path.splitext(fn)[0]
        dst = os.path.join(OUT, base + ".html")
        with open(dst, "w", encoding="utf-8") as f:
            f.write(body)

        words = len(re.findall(r"\S+", re.sub(r"<[^>]+>", " ", body)))
        h2 = body.count("<h2>")
        h3 = body.count("<h3>")
        note = "؛ ".join(msgs[:2]) if msgs else "سالم"
        rows.append((fn, title or "«بدون عنوان»", words, h2, h3, note))
        manifest.append({
            "file": base + ".html",
            "source": fn,
            "title": title or base,
            "slug": slugify_hint(title),
            "words": words, "h2": h2, "h3": h3,
        })

    with open("/home/user/maghalat/manifest2.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    lines = ["# گزارش تبدیل مقالات", "",
             "| فایل | عنوان | کلمات | H2 | H3 | وضعیت |",
             "|---|---|---|---|---|---|"]
    for r in rows:
        lines.append("| " + " | ".join(str(x) for x in r) + " |")
    lines += ["", f"**جمع:** {len(rows)} فایل — خروجی در `/home/user/maghalat/html/`"]
    rep = "\n".join(lines)
    open("/home/user/maghalat/gozaresh2.md", "w", encoding="utf-8").write(rep)
    print(rep)


if __name__ == "__main__":
    main()
