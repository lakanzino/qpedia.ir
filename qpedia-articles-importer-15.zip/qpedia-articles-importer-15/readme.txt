=== Qpedia Articles Importer — New 15 ===
Contributors: qpedia
Tags: importer
Stable tag: 1.2.0-new15

One-time importer that creates the 15 NEW articles (batches 6, 7 and 8) as `quantum_article` drafts and assigns `quantum_category` terms. Published posts are never overwritten; existing drafts are updated by slug.
