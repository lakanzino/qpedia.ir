=== Qpedia Articles Importer — Batch 6 ===
Contributors: qpedia
Tags: importer
Stable tag: 1.1.0-batch6

One-time importer that creates ONLY the 4 new batch-6 articles (LED, flash memory, scanning tunneling microscope, fiber optics) as `quantum_article` drafts and assigns `quantum_category` terms. Published posts are never overwritten; existing drafts are updated by slug.
