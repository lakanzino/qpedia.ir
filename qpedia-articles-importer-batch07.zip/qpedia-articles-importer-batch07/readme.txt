=== Qpedia Articles Importer — Batch 7 ===
Contributors: qpedia
Tags: importer
Stable tag: 1.1.0-batch7

One-time importer that creates ONLY the 4 batch-7 articles (quantum supremacy, Shor's algorithm, Grover's algorithm, quantum error correction) as `quantum_article` drafts and assigns `quantum_category` terms. Published posts are never overwritten; existing drafts are updated by slug.
