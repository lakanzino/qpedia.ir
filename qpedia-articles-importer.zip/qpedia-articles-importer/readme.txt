=== Qpedia Articles Importer ===
Contributors: qpedia
Tags: importer
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.0.0
License: GPL-2.0-or-later

One-time importer that creates 20 prepared QPedia articles as `quantum_article` drafts and assigns `quantum_category` terms. Published posts are never overwritten.

== Installation ==
1. Upload the `qpedia-articles-importer` folder to `/wp-content/plugins/`.
2. Activate the plugin.
3. Go to Tools → "ورود مقالات کیوپدیا" and click the import button.
4. Delete the plugin after publishing.
