=== Qpedia Site Fixes ===
Contributors: qpedia
Requires at least: 5.0
Stable tag: 1.0.0
License: GPL-2.0-or-later

One-time structural fixes: delete duplicate Einstein record (slug "2060") and fix Max Planck slug (max-plank -> max-planck). Run from Tools -> اصلاحات کیوپدیا, then delete the plugin.
