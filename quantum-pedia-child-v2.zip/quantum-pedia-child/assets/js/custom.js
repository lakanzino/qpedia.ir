/**
 * Quantum Pedia Child UI & Reading Experience Scripts
 *
 * @package Quantum_Pedia_Child
 */
(function () {
  'use strict';

  // ۱. کنترل منوی کشویی دسته‌بندی‌ها در هدر
  document.querySelectorAll('.qp-desktop-nav__toggle').forEach(function (button) {
    button.addEventListener('click', function (event) {
      event.preventDefault();
      var item = button.closest('.qp-desktop-nav__item');
      var expanded = button.getAttribute('aria-expanded') === 'true';

      document.querySelectorAll('.qp-desktop-nav__item.is-open').forEach(function (openItem) {
        if (openItem !== item) {
          openItem.classList.remove('is-open');
          var openBtn = openItem.querySelector('.qp-desktop-nav__toggle');
          if (openBtn) {
            openBtn.setAttribute('aria-expanded', 'false');
          }
        }
      });

      item.classList.toggle('is-open', !expanded);
      button.setAttribute('aria-expanded', expanded ? 'false' : 'true');
    });
  });

  document.addEventListener('click', function (event) {
    if (!event.target.closest('.qp-desktop-nav__item')) {
      document.querySelectorAll('.qp-desktop-nav__item.is-open').forEach(function (item) {
        item.classList.remove('is-open');
        var btn = item.querySelector('.qp-desktop-nav__toggle');
        if (btn) {
          btn.setAttribute('aria-expanded', 'false');
        }
      });
    }
  });

  // ۲. نوار پیشرفت مطالعه (Reading Progress Bar)
  var progressBar = document.getElementById('qpReadingProgressBar');
  if (progressBar) {
    window.addEventListener('scroll', function () {
      var docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (docHeight > 0) {
        var scrolled = (window.scrollY / docHeight) * 100;
        progressBar.style.width = Math.min(100, Math.max(0, scrolled)) + '%';
      }
    }, { passive: true });
  }

  // ۳. اسکرول نرم و هایلایت سرفصل‌های فهرست مطالب (TOC)
  var tocLinks = document.querySelectorAll('.qp-toc-link');
  if (tocLinks.length > 0) {
    tocLinks.forEach(function (link) {
      link.addEventListener('click', function (e) {
        var targetId = link.getAttribute('href');
        if (targetId && targetId.startsWith('#')) {
          var targetElem = document.querySelector(targetId);
          if (targetElem) {
            e.preventDefault();
            var headerOffset = 90;
            var elementPosition = targetElem.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
              top: offsetPosition,
              behavior: 'smooth'
            });
          }
        }
      });
    });

    // فعال‌سازی هایلایت خودکار هنگام اسکرول
    if ('IntersectionObserver' in window) {
      var headings = document.querySelectorAll('.qp-scroll-heading');
      var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var id = entry.target.getAttribute('id');
            tocLinks.forEach(function (link) {
              if (link.getAttribute('href') === '#' + id) {
                link.parentElement.classList.add('is-active');
              } else {
                link.parentElement.classList.remove('is-active');
              }
            });
          }
        });
      }, {
        rootMargin: '-80px 0px -70% 0px',
        threshold: 0
      });

      headings.forEach(function (heading) {
        observer.observe(heading);
      });
    }
  }

})();
