<?php
/**
 * Quantum Pedia Child — نسخهٔ سبک و تمیز
 * هدف: فقط ساختارهای ضروری سایت در پوسته بماند.
 *
 * نگه داشته شد:
 * - بارگذاری style.css و qpedia-layouts.css
 * - ثبت CPTهای quantum_article و quantum_scientist
 * - ثبت taxonomy اصلی quantum_category
 * - لینک تخت برای مقاله‌ها: /slug/
 * - آرشیو دانشمندان: /scientists/
 * - query صفحهٔ اصلی/جست‌وجو/دسته‌ها و دانشمندان
 * - ریدایرکت 301 از /glossary/ به صفحهٔ اصلی
 *
 * عمداً حذف شد:
 * - متاهای SEO، schema، canonical، Open Graph
 * - robots.txt سفارشی
 * - هدرهای امنیتی/CSP
 * - پاک‌سازی دیتابیس و cron از داخل پوسته
 * - quantum_term / quantum_column / article_domain قدیمی
 * - هدر/فوتر تزریقی و JSهای سنگین
 * - loop_start و هاب تکراری صفحهٔ اول
 * - custom.css قدیمی
 * - مسیر عمومی /glossary/ به‌عنوان آرشیو تکراری
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'QPEDIA_CHILD_VERSION', '2026.08.26-ui2' );

/**
 * استایل‌های ضروری پوستهٔ فرزند
 */
function qpedia_child_enqueue_assets() {
	$theme_version = wp_get_theme()->get( 'Version' );

	wp_enqueue_style(
		'qpedia-child-style',
		get_stylesheet_uri(),
		array(),
		$theme_version
	);

	$layouts_file = get_stylesheet_directory() . '/assets/css/qpedia-layouts.css';
	if ( file_exists( $layouts_file ) ) {
		wp_enqueue_style(
			'qpedia-layouts',
			get_stylesheet_directory_uri() . '/assets/css/qpedia-layouts.css',
			array( 'qpedia-child-style' ),
			filemtime( $layouts_file )
		);
	}

	$custom_file = get_stylesheet_directory() . '/assets/css/custom.css';
	if ( file_exists( $custom_file ) ) {
		wp_enqueue_style(
			'qpedia-child-custom',
			get_stylesheet_directory_uri() . '/assets/css/custom.css',
			array( 'qpedia-layouts' ),
			filemtime( $custom_file )
		);
	}

	$custom_js = get_stylesheet_directory() . '/assets/js/custom.js';
	if ( file_exists( $custom_js ) ) {
		wp_enqueue_script(
			'qpedia-child-custom',
			get_stylesheet_directory_uri() . '/assets/js/custom.js',
			array(),
			filemtime( $custom_js ),
			true
		);
	}
}
add_action( 'wp_enqueue_scripts', 'qpedia_child_enqueue_assets', 20 );

/**
 * پاک‌سازی سبکِ head
 */
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );

add_filter( 'xmlrpc_enabled', '__return_false' );

/**
 * ثبت ساختارهای اصلی محتوا
 */
function qpedia_child_register_content_types() {
	register_post_type(
		'quantum_article',
		array(
			'labels' => array(
				'name'          => 'مقالات کوانتوم',
				'singular_name' => 'مقالهٔ کوانتوم',
				'add_new_item'  => 'افزودن مقالهٔ جدید',
				'edit_item'     => 'ویرایش مقاله',
			),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_rest'       => true,
			'menu_icon'          => 'dashicons-media-document',
			'supports'           => array( 'title', 'editor', 'excerpt', 'thumbnail', 'author' ),
			'has_archive'        => false,
			'rewrite'            => false,
			'query_var'          => 'quantum_article',
		)
	);

	register_post_type(
		'quantum_scientist',
		array(
			'labels' => array(
				'name'          => 'دانشمندان کوانتوم',
				'singular_name' => 'دانشمند کوانتوم',
				'add_new_item'  => 'افزودن دانشمند جدید',
				'edit_item'     => 'ویرایش دانشمند',
			),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_rest'       => true,
			'menu_icon'          => 'dashicons-groups',
			'supports'           => array( 'title', 'editor', 'excerpt', 'thumbnail', 'author' ),
			'has_archive'        => 'scientists',
			'rewrite'            => array(
				'slug'       => 'scientists',
				'with_front' => false,
			),
		)
	);

	register_taxonomy(
		'quantum_category',
		array( 'quantum_article' ),
		array(
			'labels' => array(
				'name'              => 'دسته‌بندی کوانتوم',
				'singular_name'     => 'دسته',
				'search_items'      => 'جست‌وجوی دسته',
				'all_items'         => 'همهٔ دسته‌ها',
				'parent_item'       => 'دستهٔ مادر',
				'parent_item_colon' => 'دستهٔ مادر:',
				'edit_item'         => 'ویرایش دسته',
				'update_item'       => 'به‌روزرسانی دسته',
				'add_new_item'      => 'افزودن دستهٔ جدید',
				'new_item_name'     => 'نام دستهٔ جدید',
				'menu_name'         => 'دسته‌بندی کوانتوم',
			),
			'hierarchical'      => true,
			'public'            => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'show_in_nav_menus' => true,
			'rewrite'           => array(
				'slug'         => 'topic',
				'with_front'   => false,
				'hierarchical' => false,
			),
		)
	);
}
add_action( 'init', 'qpedia_child_register_content_types', 5 );

/**
 * rewriteهای ضروری سایت
 */
function qpedia_child_rewrite_rules() {
	// مقاله‌های تخت: /qubit/
	// این rule باید بالاتر از rule عمومی page باشد تا مقاله‌ها 404 نشوند.
	// هم‌زمان مسیرهای رزروشده را مستثنا می‌کنیم.
	add_rewrite_rule(
		'^(?!scientists/?$)(?!topic/)(?!wp-admin/?$)(?!wp-json/?$)(?!feed/?$)(?!page/)(?!search/?$)(?!robots\\\\.txt$)(?!favicon\\\\.ico$)(?!xmlrpc\\\\.php$)(?!wp-login\\\\.php$)(?!sitemap.*\\\\.xml$)([a-z0-9][a-z0-9\\\\-]{2,})/?$',
		'index.php?quantum_article=$matches[1]',
		'top'
	);
}
add_action( 'init', 'qpedia_child_rewrite_rules', 20 );

/**
 * جلوگیری از بلعیده‌شدن مسیرهای سیستمی و رزرو شده
 */
function qpedia_child_filter_article_request( $query_vars ) {
	if ( empty( $query_vars['quantum_article'] ) ) {
		return $query_vars;
	}

	$slug = sanitize_title_for_query( $query_vars['quantum_article'] );

	$reserved = array(
		'glossary',
		'scientists',
		'topic',
		'page',
		'feed',
		'author',
		'category',
		'tag',
		'search',
		'wp-json',
		'wp-admin',
		'wp-login',
		'xmlrpc',
		'robots',
		'favicon',
		'sitemap',
	);

	if ( in_array( $slug, $reserved, true ) ) {
		unset( $query_vars['quantum_article'] );
		return $query_vars;
	}

	$article = get_page_by_path( $slug, OBJECT, 'quantum_article' );
	if ( ! $article ) {
		unset( $query_vars['quantum_article'] );
	}

	return $query_vars;
}
add_filter( 'request', 'qpedia_child_filter_article_request' );

/**
 * لینک درست مقاله‌های تخت
 */
function qpedia_child_article_permalink( $post_link, $post ) {
	if ( isset( $post->post_type ) && 'quantum_article' === $post->post_type ) {
		return home_url( '/' . $post->post_name . '/' );
	}

	return $post_link;
}
add_filter( 'post_type_link', 'qpedia_child_article_permalink', 10, 2 );

/**
 * یک بار flush پس از جایگزینی فایل
 */
function qpedia_child_maybe_flush_rewrites() {
	$version = 'qpedia-lite-2026-08-26';
	if ( get_option( 'qpedia_child_rewrite_version' ) !== $version ) {
		flush_rewrite_rules();
		update_option( 'qpedia_child_rewrite_version', $version, false );
	}
}
add_action( 'init', 'qpedia_child_maybe_flush_rewrites', 99 );

/**
 * جمع‌کردن مسیر قدیمی glossary
 */
function qpedia_child_redirect_legacy_glossary() {
	$request_path = wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
	$request_path = is_string( $request_path ) ? trim( $request_path, '/' ) : '';

	if ( 'glossary' === $request_path ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'qpedia_child_redirect_legacy_glossary', 1 );

/**
 * تنظیم queryهای ضروری
 */
function qpedia_child_main_queries( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}

	// اگر خانه روی «آخرین نوشته‌ها» باشد، مقالات کوانتوم را نشان بده.
	if ( $query->is_home() ) {
		$query->set( 'post_type', array( 'quantum_article' ) );
		$query->set( 'posts_per_page', 12 );
		$query->set( 'ignore_sticky_posts', true );
		return;
	}

	// جست‌وجو: مقاله + دانشمند + برگه.
	if ( $query->is_search() ) {
		$query->set( 'post_type', array( 'quantum_article', 'quantum_scientist', 'page' ) );
		$query->set( 'posts_per_page', 12 );
		return;
	}

	// آرشیو دانشمندان.
	if ( $query->is_post_type_archive( 'quantum_scientist' ) ) {
		$query->set( 'posts_per_page', 24 );
		$query->set( 'ignore_sticky_posts', true );
		return;
	}

	// آرشیو دستهٔ کوانتومی.
	if ( $query->is_tax( 'quantum_category' ) ) {
		$query->set( 'post_type', array( 'quantum_article' ) );
		$query->set( 'posts_per_page', 24 );
	}
}
add_action( 'pre_get_posts', 'qpedia_child_main_queries' );

/**
 * نرمال‌سازی جست‌وجوی فارسی
 */
function qpedia_child_normalize_search_query( $query ) {
	if ( is_search() ) {
		$query = str_replace( array( 'ي', 'ك', '‌' ), array( 'ی', 'ک', ' ' ), $query );
	}
	return $query;
}
add_filter( 'get_search_query', 'qpedia_child_normalize_search_query' );


/**
 * QPEDIA — وصلهٔ سایت‌مپ بومی وردپرس
 * این بلوک را بدون <?php در انتهای functions.php بچسبان.
 */
if ( ! function_exists( 'qpedia_is_native_sitemap_request' ) ) {
    function qpedia_is_native_sitemap_request() {
        $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
        $path        = wp_parse_url( $request_uri, PHP_URL_PATH );
        $path        = is_string( $path ) ? trim( $path, '/' ) : '';

        if ( '' === $path ) {
            return false;
        }

        return (bool) preg_match( '/^wp-sitemap(?:-[a-z0-9_-]+)*(?:-\d+)?\.xml$/i', $path );
    }
}

if ( ! function_exists( 'qpedia_native_sitemap_pre_handle_404' ) ) {
    function qpedia_native_sitemap_pre_handle_404( $preempt, $wp_query ) {
        if ( is_admin() || ! qpedia_is_native_sitemap_request() ) {
            return $preempt;
        }

        if ( is_object( $wp_query ) && isset( $wp_query->is_404 ) ) {
            $wp_query->is_404 = false;
        }

        status_header( 200 );
        return true;
    }
}
add_filter( 'pre_handle_404', 'qpedia_native_sitemap_pre_handle_404', 10, 2 );

if ( ! function_exists( 'qpedia_filter_sitemap_provider' ) ) {
    function qpedia_filter_sitemap_provider( $provider, $name ) {
        if ( 'users' === $name ) {
            return false;
        }

        return $provider;
    }
}
add_filter( 'wp_sitemaps_add_provider', 'qpedia_filter_sitemap_provider', 10, 2 );

if ( ! function_exists( 'qpedia_filter_sitemap_taxonomies' ) ) {
    function qpedia_filter_sitemap_taxonomies( $taxonomies ) {
        unset( $taxonomies['article_domain'] );
        unset( $taxonomies['scientist_field'] );

        return $taxonomies;
    }
}
add_filter( 'wp_sitemaps_taxonomies', 'qpedia_filter_sitemap_taxonomies' );


/**
 * پیدا کردن آدرس برگه از بین چند اسلاگ محتمل.
 *
 * @param array<int,string> $candidate_slugs اسلاگ‌های احتمالی.
 * @param string            $fallback_path   مسیر جایگزین.
 * @return string
 */
function qpedia_child_find_page_url( $candidate_slugs, $fallback_path = '/' ) {
	if ( empty( $candidate_slugs ) || ! is_array( $candidate_slugs ) ) {
		return home_url( $fallback_path );
	}

	foreach ( $candidate_slugs as $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page instanceof WP_Post ) {
			return get_permalink( $page );
		}
	}

	return home_url( $fallback_path );
}
