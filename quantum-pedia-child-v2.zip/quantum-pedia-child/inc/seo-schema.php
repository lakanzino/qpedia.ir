<?php
/**
 * QPedia Native Technical SEO & Schema.org JSON-LD Engine
 *
 * Provides conflict-free Canonical, OpenGraph, Twitter Cards, and Schema.org
 * structured data (Article, Person, FAQPage, BreadcrumbList) for QPedia.
 *
 * @package Quantum_Pedia_Child
 */

defined( 'ABSPATH' ) || exit;

/**
 * بررسی می‌کند که آیا افزونه سئوی مجزا (مانند Yoast یا RankMath) فعال است یا خیر.
 * در صورت فعال بودن افزونه خارجی، برای جلوگیری از تداخل و متای تکراری، سیستم بومی غیرفعال می‌شود.
 */
function qpedia_has_external_seo_plugin() {
	if ( defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) ) {
		return true;
	}
	return false;
}

/**
 * محاسبه و تولید آدرس کانونیکال (Canonical URL) دقیق
 */
function qpedia_get_canonical_url() {
	if ( is_front_page() || is_home() ) {
		return home_url( '/' );
	}

	if ( is_singular( 'quantum_article' ) ) {
		global $post;
		return home_url( '/' . $post->post_name . '/' );
	}

	if ( is_singular() ) {
		return get_permalink();
	}

	if ( is_tax( 'quantum_category' ) ) {
		$term = get_queried_object();
		return $term ? get_term_link( $term ) : home_url( '/' );
	}

	if ( is_post_type_archive( 'quantum_scientist' ) ) {
		return home_url( '/scientists/' );
	}

	if ( is_search() ) {
		return home_url( '/?s=' . rawurlencode( get_search_query() ) );
	}

	return home_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) );
}

/**
 * دریافت تصویر پیش‌فرض یا تصویر شاخص برای متاتگ‌ها و اسکیما
 */
function qpedia_get_og_image_url() {
	if ( is_singular() && has_post_thumbnail() ) {
		$img_src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' );
		if ( ! empty( $img_src[0] ) ) {
			return $img_src[0];
		}
	}
	return get_stylesheet_directory_uri() . '/assets/images/qpedia-hero-emblem.png';
}

/**
 * دریافت متن توضیحات (Meta Description) بهینه‌شده
 */
function qpedia_get_meta_description() {
	if ( is_front_page() || is_home() ) {
		return 'دانشنامه تخصصی فیزیک و فناوری‌های کوانتومی به زبان ساده؛ پلی میان ژرفای علم ذرات و نسل جوان ایران.';
	}

	if ( is_singular() ) {
		global $post;
		if ( ! empty( $post->post_excerpt ) ) {
			return wp_strip_all_tags( $post->post_excerpt );
		}
		$content = wp_strip_all_tags( $post->post_content );
		return wp_trim_words( $content, 28, '...' );
	}

	if ( is_tax( 'quantum_category' ) ) {
		$term = get_queried_object();
		if ( $term && ! empty( $term->description ) ) {
			return wp_strip_all_tags( $term->description );
		}
		return 'مجموعه مقالات و مفاهیم تخصصی در حوزه ' . ( $term ? $term->name : 'کوانتوم' );
	}

	return get_bloginfo( 'description' );
}

/**
 * چاپ تگ‌های کانونیکال، اوپن گراف و توییتر کارت در head
 */
function qpedia_output_seo_meta_tags() {
	if ( qpedia_has_external_seo_plugin() || is_admin() ) {
		return;
	}

	$canonical_url = qpedia_get_canonical_url();
	$meta_desc     = esc_attr( qpedia_get_meta_description() );
	$og_image      = esc_url( qpedia_get_og_image_url() );
	$site_title    = get_bloginfo( 'name' );

	$page_title = $site_title;
	if ( is_singular() ) {
		$page_title = single_post_title( '', false ) . ' | ' . $site_title;
	} elseif ( is_tax( 'quantum_category' ) ) {
		$term = get_queried_object();
		$page_title = ( $term ? $term->name : 'دسته' ) . ' | دانشنامه کوانتوم‌پدیا';
	} elseif ( is_post_type_archive( 'quantum_scientist' ) ) {
		$page_title = 'تالار دانشمندان کوانتوم | ' . $site_title;
	}
	?>

	<!-- QPedia Native SEO Engine -->
	<link rel="canonical" href="<?php echo esc_url( $canonical_url ); ?>" />
	<meta name="description" content="<?php echo $meta_desc; ?>" />

	<!-- Open Graph / Facebook -->
	<meta property="og:locale" content="fa_IR" />
	<meta property="og:site_name" content="<?php echo esc_attr( $site_title ); ?>" />
	<meta property="og:type" content="<?php echo is_singular() ? 'article' : 'website'; ?>" />
	<meta property="og:title" content="<?php echo esc_attr( $page_title ); ?>" />
	<meta property="og:description" content="<?php echo $meta_desc; ?>" />
	<meta property="og:url" content="<?php echo esc_url( $canonical_url ); ?>" />
	<meta property="og:image" content="<?php echo $og_image; ?>" />
	<?php if ( is_singular() ) : ?>
		<meta property="article:published_time" content="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" />
		<meta property="article:modified_time" content="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>" />
	<?php endif; ?>

	<!-- Twitter Cards -->
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:title" content="<?php echo esc_attr( $page_title ); ?>" />
	<meta name="twitter:description" content="<?php echo $meta_desc; ?>" />
	<meta name="twitter:image" content="<?php echo $og_image; ?>" />
	<?php
}
add_action( 'wp_head', 'qpedia_output_seo_meta_tags', 1 );

/**
 * استخراج خودکار پرسش و پاسخ‌ها از متن مقاله جهت تولید اسکیما FAQPage
 *
 * @param string $content متن مقاله.
 * @return array<int,array{q:string,a:string}>
 */
function qpedia_extract_faq_items( $content ) {
	$faqs = array();

	// روش ۱: جستجو در تگ‌های <details><summary>پرسش</summary>پاسخ</details>
	if ( preg_match_all( '/<details[^>]*>\s*<summary[^>]*>(.*?)<\/summary>(.*?)<\/details>/is', $content, $matches, PREG_SET_ORDER ) ) {
		foreach ( $matches as $m ) {
			$q = trim( wp_strip_all_tags( $m[1] ) );
			$a = trim( wp_strip_all_tags( $m[2] ) );
			if ( ! empty( $q ) && ! empty( $a ) ) {
				$faqs[] = array( 'q' => $q, 'a' => $a );
			}
		}
	}

	// روش ۲: جستجو در ساختار H3 / P در زیر بخش سؤالات متداول
	if ( empty( $faqs ) && preg_match( '/<h2[^>]*>.*?(?:پرسش|سوال|سؤال).*?<\/h2>(.*?)(?=<h2|$)/is', $content, $sec_match ) ) {
		$faq_section = $sec_match[1];
		if ( preg_match_all( '/<h3[^>]*>(.*?)<\/h3>\s*<p[^>]*>(.*?)<\/p>/is', $faq_section, $q_matches, PREG_SET_ORDER ) ) {
			foreach ( $q_matches as $qm ) {
				$q = trim( wp_strip_all_tags( $qm[1] ) );
				$a = trim( wp_strip_all_tags( $qm[2] ) );
				if ( ! empty( $q ) && ! empty( $a ) ) {
					$faqs[] = array( 'q' => $q, 'a' => $a );
				}
			}
		}
	}

	return $faqs;
}

/**
 * تزریق داده‌های ساختاریافته Schema.org در قالب JSON-LD
 */
function qpedia_output_json_ld_schemas() {
	if ( qpedia_has_external_seo_plugin() || is_admin() ) {
		return;
	}

	$schemas = array();
	$site_url = home_url( '/' );

	// ۱. اسکیما سراسری وبسایت و سازمان
	if ( is_front_page() || is_home() ) {
		$schemas[] = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'WebSite',
			'@id'             => $site_url . '#website',
			'url'             => $site_url,
			'name'            => 'کوانتوم‌پدیا',
			'alternateName'   => 'QPedia.ir',
			'description'     => 'دانشنامه تخصصی فیزیک و محاسبات کوانتومی به زبان ساده',
			'inLanguage'      => 'fa-IR',
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => array(
					'@type'       => 'EntryPoint',
					'urlTemplate' => $site_url . '?s={search_term_string}',
				),
				'query-input' => 'required name=search_term_string',
			),
			'publisher'       => array(
				'@type' => 'Organization',
				'name'  => 'کوانتوم پدیا فارسی',
				'url'   => $site_url,
				'logo'  => array(
					'@type' => 'ImageObject',
					'url'   => get_stylesheet_directory_uri() . '/assets/images/qpedia-logo-white.png',
				),
			),
		);
	}

	// ۲. اسکیما مسیر راهنما (BreadcrumbList)
	if ( ! is_front_page() && ! is_home() ) {
		$breadcrumb_items = array();
		$pos = 1;
		$breadcrumb_items[] = array(
			'@type'    => 'ListItem',
			'position' => $pos++,
			'name'     => 'صفحه نخست',
			'item'     => $site_url,
		);

		if ( is_singular( 'quantum_article' ) ) {
			$terms = get_the_terms( get_the_ID(), 'quantum_category' );
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				$primary = $terms[0];
				$breadcrumb_items[] = array(
					'@type'    => 'ListItem',
					'position' => $pos++,
					'name'     => $primary->name,
					'item'     => get_term_link( $primary ),
				);
			}
			$breadcrumb_items[] = array(
				'@type'    => 'ListItem',
				'position' => $pos++,
				'name'     => get_the_title(),
				'item'     => qpedia_get_canonical_url(),
			);
		} elseif ( is_singular( 'quantum_scientist' ) ) {
			$breadcrumb_items[] = array(
				'@type'    => 'ListItem',
				'position' => $pos++,
				'name'     => 'تالار دانشمندان',
				'item'     => home_url( '/scientists/' ),
			);
			$breadcrumb_items[] = array(
				'@type'    => 'ListItem',
				'position' => $pos++,
				'name'     => get_the_title(),
				'item'     => get_permalink(),
			);
		} elseif ( is_tax( 'quantum_category' ) ) {
			$term = get_queried_object();
			if ( $term ) {
				$breadcrumb_items[] = array(
					'@type'    => 'ListItem',
					'position' => $pos++,
					'name'     => $term->name,
					'item'     => get_term_link( $term ),
				);
			}
		}

		if ( count( $breadcrumb_items ) > 1 ) {
			$schemas[] = array(
				'@context'        => 'https://schema.org',
				'@type'           => 'BreadcrumbList',
				'itemListElement' => $breadcrumb_items,
			);
		}
	}

	// ۳. اسکیما مقاله (Article / TechArticle)
	if ( is_singular( 'quantum_article' ) ) {
		global $post;
		$post_id   = get_the_ID();
		$faqs      = qpedia_extract_faq_items( $post->post_content );
		$image_url = qpedia_get_og_image_url();

		$schemas[] = array(
			'@context'         => 'https://schema.org',
			'@type'            => 'TechArticle',
			'@id'              => get_permalink() . '#article',
			'headline'         => get_the_title(),
			'description'      => qpedia_get_meta_description(),
			'inLanguage'       => 'fa-IR',
			'image'            => $image_url,
			'datePublished'    => get_the_date( 'c' ),
			'dateModified'     => get_the_modified_date( 'c' ),
			'mainEntityOfPage' => qpedia_get_canonical_url(),
			'author'           => array(
				'@type' => 'Organization',
				'name'  => 'هیئت تحریریه کوانتوم‌پدیا',
				'url'   => $site_url,
			),
			'publisher'        => array(
				'@type' => 'Organization',
				'name'  => 'کوانتوم‌پدیا',
				'url'   => $site_url,
				'logo'  => array(
					'@type' => 'ImageObject',
					'url'   => get_stylesheet_directory_uri() . '/assets/images/qpedia-logo-white.png',
				),
			),
		);

		// اسکیما سؤالات متداول (FAQPage) در صورت وجود
		if ( ! empty( $faqs ) ) {
			$faq_entities = array();
			foreach ( $faqs as $item ) {
				$faq_entities[] = array(
					'@type'          => 'Question',
					'name'           => $item['q'],
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => $item['a'],
					),
				);
			}

			$schemas[] = array(
				'@context'   => 'https://schema.org',
				'@type'      => 'FAQPage',
				'mainEntity' => $faq_entities,
			);
		}
	}

	// ۴. اسکیما بیوگرافی دانشمند (Person)
	if ( is_singular( 'quantum_scientist' ) ) {
		$sci_id   = get_the_ID();
		$en_name  = trim( (string) get_post_meta( $sci_id, '_scientist_en_name', true ) );
		$nobel    = trim( (string) get_post_meta( $sci_id, '_scientist_nobel_year', true ) );
		$image_url = qpedia_get_og_image_url();

		$person_schema = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'Person',
			'@id'         => get_permalink() . '#person',
			'name'        => get_the_title(),
			'image'       => $image_url,
			'description' => qpedia_get_meta_description(),
			'jobTitle'    => 'فیزیک‌دان کوانتوم',
			'knowsAbout'  => array( 'Quantum Mechanics', 'Theoretical Physics', 'Quantum Physics' ),
		);

		if ( $en_name ) {
			$person_schema['alternateName'] = $en_name;
		}
		if ( $nobel ) {
			$person_schema['award'] = 'Nobel Prize in Physics (' . $nobel . ')';
		}

		$schemas[] = $person_schema;
	}

	// خروجی JSON-LD امن و اعتبارسنجی‌شده
	if ( ! empty( $schemas ) ) {
		echo "\n<!-- QPedia Structured Data (Schema.org) -->\n";
		foreach ( $schemas as $schema ) {
			echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) . "</script>\n";
		}
	}
}
add_action( 'wp_head', 'qpedia_output_json_ld_schemas', 2 );
